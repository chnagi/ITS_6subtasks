# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from .models import area,Farmer,Familymembers,familyphotos,familyaudioclips,farm,housepoint,crops,wells,wellyield
#,wells,landmap
#,Housemark
# Register your models here.
admin.site.register(Farmer)
admin.site.register(Familymembers)
admin.site.register(familyphotos)
admin.site.register(familyaudioclips)
admin.site.register(farm)
admin.site.register(housepoint)
admin.site.register(crops)
admin.site.register(wells)
admin.site.register(area)
admin.site.register(wellyield)
#admin.site.register(landmap)
#admin.site.register(Housemark)"""
