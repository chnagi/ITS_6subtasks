from rest_framework import serializers
from .models import area,Farmer,Familymembers,familyphotos,familyaudioclips,farm,housepoint,crops,wells,wellyield

#,Points,Familymembers,wells,landmap
#,Housemark
class FarmerSerializer(serializers.ModelSerializer):
	class Meta:
		model=Farmer
		fields='__all__'
class FamilymembersSerializer(serializers.ModelSerializer):
	class Meta:
		model=Familymembers
		fields='__all__'
class familyphotosSerializer(serializers.ModelSerializer):
	class Meta:
		model=familyphotos
		fields='__all__'
class familyaudioclipsSerializer(serializers.ModelSerializer):
	class Meta:
		model=familyaudioclips
		fields='__all__'
class farmSerializer(serializers.ModelSerializer):
	class Meta:
		model=farm
		fields='__all__'
class housepointSerializer(serializers.ModelSerializer):
	class Meta:
		model=housepoint
		fields='__all__'
class cropsSerializer(serializers.ModelSerializer):
	class Meta:
		model=crops
		fields='__all__'
class wellsSerializer(serializers.ModelSerializer):
	class Meta:
		model=wells
		fields='__all__'
class wellyieldSerializer(serializers.ModelSerializer):
	class Meta:
		model=wellyield
		fields='__all__'
class areaSerializer(serializers.ModelSerializer):
	class Meta:
		model=area
		fields='__all__'



