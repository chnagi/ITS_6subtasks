# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import datetime 
from django.db import models
from django.contrib.gis.db import models
from django.core.files.storage import FileSystemStorage
# Create your models here.
class Farmer(models.Model):
	farmer_id=models.IntegerField(default=0,primary_key=True)
	farmer_name=models.CharField(max_length=200)
	mobile_no=models.CharField(max_length=200)
	Adhar_no=models.CharField(max_length=200)
	Annual_income=models.IntegerField(default=0)
	def __str__(self):
		return self.farmer_name
	#mpoly=models.PolygonField()
   
class Familymembers(models.Model):
	gender=(('F','Female'),('M','Male'))
	farmer_id=models.ForeignKey(Farmer,on_delete=models.CASCADE)
	member_name=models.CharField(max_length=200)
	member_age=models.IntegerField(default=1)
	member_gender=models.CharField(max_length=50,choices=gender)
class familyphotos(models.Model):
	farmer_id=models.ForeignKey(Farmer,on_delete=models.CASCADE)
	photo=models.ImageField(upload_to='familyphotos')
class familyaudioclips(models.Model):
	farmer_id=models.ForeignKey(Farmer,on_delete=models.CASCADE)
	audio=models.FileField(upload_to="audios")
class farm(models.Model):
	farmer_id=models.ForeignKey(Farmer,on_delete=models.CASCADE)
	farm_id=models.IntegerField(default=0)
	farm_lat=models.FloatField()
	farm_lng=models.FloatField()
class housepoint(models.Model):
	farmer_id=models.ForeignKey(Farmer,on_delete=models.CASCADE)
	house_lat=models.FloatField()
	house_lng=models.FloatField()
class crops(models.Model):
	farmer_id=models.ForeignKey(Farmer,on_delete=models.CASCADE)

	farm_id=models.IntegerField(default=0)
	khareef=models.CharField(max_length=200)
	khareef_area=models.IntegerField(default=0)
	rabi=models.CharField(max_length=20)
	rabi_area=models.IntegerField(default=0)	
	time=models.DateField(default=datetime.date.today)
class wells(models.Model):
        farmer_id=models.ForeignKey(Farmer,on_delete=models.CASCADE)
	well_id=models.IntegerField(default=0,primary_key=False)
	well_lat=models.FloatField()
	well_lng=models.FloatField()
	depth=models.FloatField(default=0)
class wellyield(models.Model):
	well_id=models.ForeignKey(wells,on_delete=models.CASCADE)
	well_yield=models.FloatField()
	well_DOB=models.DateField(default=datetime.date.today)
class area(models.Model):
	farmer_id=models.ForeignKey(Farmer,on_delete=models.CASCADE)
	area=models.IntegerField(default=0)
