# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

# Create your views here.
from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import area,Farmer,Familymembers,familyphotos,familyaudioclips,farm,housepoint,crops,wells,wellyield
from .serializers import areaSerializer,FarmerSerializer,FamilymembersSerializer,familyphotosSerializer,familyaudioclipsSerializer,farmSerializer,housepointSerializer,cropsSerializer,wellsSerializer,wellyieldSerializer

# Create your views here.
class FarmerList(APIView):
    def get(self,request):
        farmers=Farmer.objects.all()
        serializer=FarmerSerializer(farmers,many=True)
        return Response(serializer.data)
       
    def post(self):
        pass
class FamilymembersList(APIView):
    def get(self,request):
        farmers=Familymembers.objects.all()
        serializer=FamilymembersSerializer(farmers,many=True)
        return Response(serializer.data)
       
    def post(self):
        pass
class familyphotosList(APIView):
    def get(self,request):
        farmers=familyphotos.objects.all()
        serializer=familyphotosSerializer(farmers,many=True)
        return Response(serializer.data)
       
    def post(self):
        pass
class familyaudioclipsList(APIView):
    def get(self,request):
        farmers=familyaudioclips.objects.all()
        serializer=familyaudioclipsSerializer(farmers,many=True)
        return Response(serializer.data)
       
    def post(self):
        pass
class farmList(APIView):
    def get(self,request):
        farmers=farm.objects.all()
        serializer=farmSerializer(farmers,many=True)
        return Response(serializer.data)
       
    def post(self):
        pass
class housepointList(APIView):
    def get(self,request):
        farmers=housepoint.objects.all()
        serializer=housepointSerializer(farmers,many=True)
        return Response(serializer.data)
       
    def post(self):
        pass        
class cropsList(APIView):
    def get(self,request):
        farmers=crops.objects.all()
        serializer=cropsSerializer(farmers,many=True)
        return Response(serializer.data)
       
    def post(self):
        pass        
class wellsList(APIView):
    def get(self,request):
        farmers=wells.objects.all()
        serializer=wellsSerializer(farmers,many=True)
        return Response(serializer.data)
       
    def post(self):
        pass        
class wellyieldList(APIView):
    def get(self,request):
        farmers=wellyield.objects.all()
        serializer=wellyieldSerializer(farmers,many=True)
        return Response(serializer.data)
       
    def post(self):
        pass        

class areaList(APIView):
    def get(self,request):
        farmers=area.objects.all()
        serializer=areaSerializer(farmers,many=True)
        return Response(serializer.data)
       
    def post(self):
        pass   

