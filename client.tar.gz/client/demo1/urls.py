from django.conf.urls import url

from . import views
app_name='demo1'
urlpatterns = [
    url(r'^$', views.search, name='search'),
    url(r'map', views.map, name='map'),
   # url(r'^$', views.get_name, name='nameform')

]










