from django import forms
class Nameform(forms.Form):
	your_name=forms.CharField(label='your name',max_length=50)
def process(self):
	cd=self.cleaned_data
