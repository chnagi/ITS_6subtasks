# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib
import json
import requests
from .nameform import Nameform
from django.template import loader,Context
from django.shortcuts import render
from django.http import HttpResponse


# in search data is sent to form.html where we search for an name of farmer
def search(request):
       
	 URL1 = "http://127.0.0.1:8000/farmer/"
	 t=loader.get_template('demo1/form.html')
	 r1 = requests.get(URL1)
	 d = r1.json()
         d1={'data':d}
	 return HttpResponse(t.render(d1,request))
# sending data from url  to template map where data is shown on map
def map(request):
        username=request.POST['farmername']
	# api-endpoint
	#username='Nagalakshmi'
	URL = "http://127.0.0.1:8000/farm/"
 	URL1 = "http://127.0.0.1:8000/farmer/"
	ur="http://127.0.0.1:8000/wells/"
	u="http://127.0.0.1:8000/housepoint/"	
	u1="http://127.0.0.1:8000/familymembers/"
	u2="http://127.0.0.1:8000/photos/"
	u3="http://127.0.0.1:8000/crops/"
	u4="http://127.0.0.1:8000/familyaudioclips/"
	u5="http://127.0.0.1:8000/wellyield/"
	r = requests.get(url = URL)
	r1=requests.get(URL1)
	data = r.json()
	dat=r1.json()
	well=(requests.get(ur)).json()
	house=(requests.get(u)).json()
	photos=(requests.get(u2)).json()
	familymembers=(requests.get(u1)).json()
	crops=(requests.get(u3)).json()
	audios=(requests.get(u4)).json()
	yield1=(requests.get(u5)).json()
	data1=[]
	#farm_id=1
	w=[]
	# getting farmer_id from selected name and stored in index
	for j in range(len(dat)):
		if(dat[j]['farmer_name']==username):
			farm_id=dat[j]['farmer_id']
			index=farm_id
			#details=dat[j]
	for h in range(len(house)):
		if (farm_id==house[h]['farmer_id']):
			w.append({key:value for key,value in house[h].items()})
	for i in range(len(data)):
		data1.append([])
 		if(data[i]['farmer_id']==farm_id):
			data1[i]= {key: value for key, value in data[i].items() }
			#data1[i]['lng']=data1[i].pop('lon')
	data1.append([])
	data1.append(data1[0])
	data2={}
	o=0;
	template=loader.get_template('demo1/map.html')
	for k in range(len(data)):
		if (data1[k]!=[]):
			#data2.append([])
			data2[o]=data1[k]
			o=o+1
	context={'d13':json.dumps(dat),'d14':json.dumps(data2),'d15':json.dumps(well),'d16':json.dumps(house),'d17':json.dumps(photos),'d12':json.dumps(familymembers),'d11':json.dumps(crops),'d10':json.dumps(audios),'d9':json.dumps(index),'d8':json.dumps(yield1)}
	return HttpResponse(template.render(context,request))
# Create your views her


